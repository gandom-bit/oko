package builders;

public interface Builder {
}
