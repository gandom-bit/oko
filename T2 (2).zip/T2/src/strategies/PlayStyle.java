package strategies;

public interface PlayStyle {
    public int calculatePower(int power);
}
