package controller;

import enums.AppMenuCommands;
import models.App;
import models.Result;
import models.User;

public class LoginMenuController {
    public Result loginUser(String username, String password){
        User user = User.getUserByUsername(username);
        if(user == null){
            return new Result(false, "username doesn't exist!");
        }
        if(!user.getPassword().equals(password)){
            return new Result(false, "password is incorrect!");
        }
        App.setCurrentUser(user);
        return new Result(true, "user logged in successfully");
        App.setMenu(AppMenuCommands.MAIN_MENU);
    }

    public Result forgotPassword(String username, String email) {
        User user = User.getUserByUsername(username);
        if(user == null){
            return new Result(false, "username doesn't exist!");
        }
        if(!user.getEmail().equals(email)){
            return new Result(false, "email doesn't match!");
        }
        return new Result(true, "password: " + user.getPassword());

    }
}
