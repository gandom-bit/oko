package controller;

import models.*;

public class SignUpMenuController {
   public Result registerUser(String username, String password, String email) {
       User user = new User();
       if (!user.validationOfUsername(username)) {
           return new Result(false, "invalid username");
       }
       if (user.userExists(username)) {
           return new Result(false, "username is already taken");
       }
       if (password.length() < 8 || password.length() > 20) {
           return new Result(false, "invalid length");
       }
       if (user.containsSpace(password)) {
           return new Result(false, "don't use whitespace in password");
       }
       if (user.startsWithLetter(password)) {
           return new Result(false, "password must start with English letters");
       }
       if(user.lacksSpecialCharacter(password)) {
           return new Result(false, "password doesn't have special characters");
       }
       if (!user.validationOfEmail(email)) {
           return new Result(false, "invalid email format");
       }

       App.addUser(user);
       return new Result(true, "user registered successfully");
   }
}
