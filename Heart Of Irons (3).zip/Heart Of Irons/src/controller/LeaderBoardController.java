package controller;

public class LeaderBoardController {
}
