package enums;

import views.*;

import java.util.Scanner;

public enum AppMenuCommands {
    SIGNUP_MENU(new SignUpMenu(), "signupmenu"),
    LOGIN_MENU(new LoginMenu(), "login"),
    LEADER_BOARD(new LeaderBoardMenu(), "leaderboard"),
    GAME_MENU(new GameMenu(), ""),
    MAIN_MENU(new MainMenu(), "mainmenu"),
    EXIT(new ExitMenu(), "");

    public AppView menu;

    AppMenuCommands(AppView menu) {
        this.menu = menu;
    }
    public void run(Scanner scanner) {
        this.menu.run(scanner);
    }
}
