package enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum SignUpMenuCommands {
    REGISTER("\\s*register\\s+-u\\s+(?<username>.*\\S)\\s+-p\\s+(?<password>.*\\S)\\s+-e\\s+(?<email>.*\\S)" +
            "\\s*"),
    USERNAME("(?<username>[a-zA-Z][a-zA-Z0-9_]*)"),
    PASSWORD("(?<password>^(?=[a-zA-Z])(?=.*[%@#$^&!])[^\\s]{8,20}$)"),
    EMAIL("(?<email>^[a-zA-Z0-9]+(\\.[a-zA-Z0-9]+)?@[a-zA-Z0-9]+\\.com$)"),
    LOGIN("\\s*login\\s*");


    private String command;

    SignUpMenuCommands(String command) {
        this.command = command;
    }

    public Matcher getMatcher(String input) {
        Matcher matcher = Pattern.compile(command).matcher(input);
        if (matcher.matches()){
            return matcher;
        }
        return null;
    }
}
