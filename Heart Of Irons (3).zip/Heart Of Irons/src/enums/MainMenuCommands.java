package enums;

public enum MainMenuCommands {
    LEADERBOARD("^\\s*leaderboard\\s*$"),
    PLAY("^\\s*play(?<users>(\\s+\\S+){0,4})\\s*$");
}
