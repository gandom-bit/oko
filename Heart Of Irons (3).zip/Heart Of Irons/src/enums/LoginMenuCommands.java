package enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum LoginMenuCommands {

        LOGIN("\\s*login\\s+-username\\s+-password\\s*"),
        FORGET_PASSWORD("\\s*forget-password\\s+-username\\s+-email\\s*)");

    private String command;

    LoginMenuCommands(String command) {
        this.command = command;
    }

    public Matcher getMatcher(String input) {
        Matcher matcher = Pattern.compile(command).matcher(input);
        if (matcher.matches()){
            return matcher;
        }
        return null;
    }
}