package enums;

public enum GameMenuCommands {
}
