package views;

import models.App;
import enums.AppMenuCommands;

import java.util.Scanner;

public class AppView {

    public static Scanner scanner = new Scanner(System.in);
    public static void run(){
        while(!App.getMenu().equals(AppMenuCommands.EXIT)){
            String input = scanner.nextLine();
}
