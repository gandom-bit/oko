package views;

import enums.AppMenuCommands;
import enums.Commands;
import models.App;

import java.util.regex.Matcher;

public abstract class AppMenu {
    public boolean run(String input){
        Matcher matcher;

        if((matcher = Commands.BACK.getMatcher(input)) != null) {
            if(App.getMenu() == AppMenuCommands.SIGNUP_MENU){
                System.out.println("invalid command");
                return true;
            }
            App.setMenu(AppMenuCommands.SIGNUP_MENU);
            return true;
        } else if((matcher = Commands.EXIT.getMatcher(input)) != null) {
            App.setMenu(AppMenuCommands.EXIT);
            return true;
        }
        return false;
    }

}
