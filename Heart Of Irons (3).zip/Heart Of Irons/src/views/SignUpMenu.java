package views;

import controller.SignUpMenuController;
import enums.AppMenuCommands;
import enums.Commands;
import enums.SignUpMenuCommands;
import models.App;
import models.Result;

import java.util.regex.Matcher;

public class SignUpMenu extends AppMenu {
    SignUpMenuController controller = new SignUpMenuController();

    @Override
    public boolean run(String input) {
        if (super.run(input)) {
            return true;
        }
        Matcher matcher;
        if ((matcher = SignUpMenuCommands.REGISTER.getMatcher(input)) != null) {
            String username = matcher.group("username").trim();
            String password = matcher.group("password").trim();
            String email = matcher.group("email").trim();

            Result result = controller.registerUser(username, password, email);
            System.out.println(result);
        } else if ((matcher = SignUpMenuCommands.LOGIN.getMatcher(input)) != null) {
            App.setMenu(AppMenuCommands.LOGIN_MENU);

        } else {
            System.out.println("invalid command");
            return false;
        }
        return true;
    }
}
