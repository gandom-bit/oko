package views;

public class LeaderBoardMenu {
}
