package views;

import controller.LoginMenuController;
import enums.LoginMenuCommands;
import models.Result;

import java.util.regex.Matcher;

public class LoginMenu extends AppMenu{
    LoginMenuController controller = new LoginMenuController();
    @Override
    public boolean run(String input) {
        if (super.run(input)) {
            return true;
        }
        Matcher matcher;
        if ((matcher = LoginMenuCommands.LOGIN.getMatcher(input)) != null) {
            String username = matcher.group("username").trim();
            String password = matcher.group("password").trim();

            Result result  = controller.loginUser(username, password);
            System.out.println(result);
        }

        if ((matcher = LoginMenuCommands.FORGET_PASSWORD.getMatcher(input)) != null) {
            String username = matcher.group("username").trim();
            String email = matcher.group("email").trim();

            Result result = controller.forgotPassword(username, email);
            System.out.println(result);
        }else {
            System.out.println("invalid command");
            return false;
        }
        return true;

    }
}
