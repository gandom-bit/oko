package views;

public class ExitMenu extends AppMenu {
}
