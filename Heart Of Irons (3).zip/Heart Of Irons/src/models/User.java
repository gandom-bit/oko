package models;

import views.AppMenu;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class User {
    private String username;
    private String password;
    private String email;
    private int points;
    private List<User> users = new ArrayList<>();

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.points = 0;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public int getPoints() {
        return points;
    }

    public void addPoints(int points) {
        this.points += points;
    }

    public boolean isUsernameTaken(String username) {
        return users.stream().anyMatch(user -> user.getUsername().equals(username));
    }

    public static User getUserByUsername(String username) {
        for (User user : App.getUsers()) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public  void registerUser(String username, String password, String email) {
        users.add(new User(username, password, email));
    }

    public List<User> getUsers() {
        return users;
    }

    public boolean validationOfUsername(String name) {
        String regex = "[a-zA-Z][a-zA-Z0-9_]*$";
        return Pattern.compile(regex).matcher(name).matches();
    }

    public boolean validationOfPassword(String password) {
        String regex = "^(?=[a-zA-Z])(?=.*[%@#$^&!])[^\\s]{8,20}$\n";
        return Pattern.compile(regex).matcher(password).matches();
    }

    public boolean validationOfEmail(String email) {
        String regex =  "^[a-zA-Z0-9]+(\\.[a-zA-Z0-9]+)?@[a-zA-Z0-9]+\\.com$";
        return Pattern.compile(regex).matcher(email).matches();
    }

    public boolean userExists(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    public boolean containsSpace(String password) {
        return password.contains(" ");
    }

    public boolean startsWithLetter(String password) {
        return password.matches("^[a-zA-Z].*");
    }

    public boolean lacksSpecialCharacter(String password) {
        return !password.matches(".*[%@#$^&!].*");
    }


}