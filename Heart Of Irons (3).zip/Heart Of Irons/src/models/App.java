package models;

import enums.AppMenuCommands;

import java.util.ArrayList;

public class App {
    private static ArrayList<User> users = new ArrayList<>();
    private static AppMenuCommands menu = AppMenuCommands.SIGNUP_MENU;
    private static User currentUser;


    public static void addUser(User user) {
        users.add(user);
    }
    public static AppMenuCommands getMenu() {
        return menu;
    }
    public static void setMenu(AppMenuCommands menu) {
        App.menu = menu;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        App.currentUser = currentUser;
    }
}
