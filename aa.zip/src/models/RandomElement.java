package models;

public interface RandomElement {
    char symbol();
    boolean isPassable();
}