package models;

public class Lake implements StaticElement {
    public char symbol() { return 'L'; }
    public boolean isPassable() { return false; }
}
