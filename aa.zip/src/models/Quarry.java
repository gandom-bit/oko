package models;

public class Quarry implements StaticElement {
    public char symbol() { return 'Q'; }
    public boolean isPassable() { return false; }
}