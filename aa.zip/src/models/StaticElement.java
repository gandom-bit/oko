package models;

public interface StaticElement {
    char symbol();       // نمایش نقشه
    boolean isPassable();
}
