package models;

public class Cabin implements StaticElement {
    public char symbol() { return 'C'; }
    public boolean isPassable() { return false; }
}
