package models;

public class Tree implements RandomElement {
    public char symbol() { return 'T'; }
    public boolean isPassable() { return false; }
}