package models;

import java.util.List;

public class ProcessingMachine {
    private String type;
    private List<Product> products;
    private String manufacturingInstruction;
}
