package models;

public class ForageItem implements RandomElement {
    public char symbol() { return 'F'; }
    public boolean isPassable() { return true; }
}