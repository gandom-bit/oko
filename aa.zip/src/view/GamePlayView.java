package view;

import java.util.Scanner;

public class GamePlayView {
    Scanner scanner;
    public GamePlayView(Scanner sc) {
        this.scanner = sc;
    }

    public void displayGamePlay() {}
}
