package view;

import java.util.Scanner;

public class InventoryView {
    Scanner scanner;
    public InventoryView(Scanner scanner) {}
    public void display() {}
}
