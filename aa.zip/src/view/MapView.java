package view;

import java.util.Scanner;

public class MapView {
    Scanner scanner;
    public void display() {}
}
