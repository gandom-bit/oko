package view;

import java.util.Scanner;

public class GameView {
    Scanner scanner;
    public GameView(Scanner scanner) {}
    public void display() {}
}
