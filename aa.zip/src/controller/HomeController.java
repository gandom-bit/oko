package controller;

import models.ProcessingMachine;
import models.Result;

import java.util.ArrayList;
import java.util.List;

public class HomeController {
    private List<ProcessingMachine> processingMachineList = new ArrayList<>();


    public Result crafting () {
        return null;
    }

    public Result cooking () {
        return null;
    }
}
