package controller;

import models.Result;

public class ToolController {
    public Result UseTool(){
        return null;
    }
    public Result upgradeTool() {
        return null;
    }
    public Result equipTool() {
        return null;
    }
}
